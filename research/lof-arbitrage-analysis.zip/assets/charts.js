(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();
  var green = style.getPropertyValue('--green').trim();

  // Chart 1: 501098 NAV Trend vs Market Price
  var chart1 = echarts.init(document.getElementById('chart-nav-trend'), null, { renderer: 'svg' });
  chart1.setOption({
    animation: false,
    tooltip: { appendToBody: true, trigger: 'axis' },
    legend: { top: 0, textStyle: { color: muted, fontSize: 12 } },
    grid: { left: 60, right: 40, top: 40, bottom: 30 },
    xAxis: {
      type: 'category',
      data: ['7/14', '7/15', '7/16', '7/17', '7/21', '7/22', '7/23'],
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: muted }
    },
    yAxis: {
      type: 'value', min: 1.5,
      axisLine: { lineStyle: { color: rule } },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } },
      axisLabel: { color: muted, formatter: '{value}' }
    },
    series: [
      {
        name: '单位净值(NAV)',
        type: 'line',
        data: [2.0389, 1.9593, 1.8580, 1.6912, 1.8195, 1.7690, 1.7175],
        lineStyle: { color: accent, width: 2 },
        itemStyle: { color: accent },
        symbol: 'circle', symbolSize: 6
      },
      {
        name: '场内收盘价',
        type: 'line',
        data: [null, null, null, null, null, 1.708, 1.708],
        lineStyle: { color: accent2, width: 2, type: 'dashed' },
        itemStyle: { color: accent2 },
        symbol: 'diamond', symbolSize: 8
      },
      {
        name: '折价区域',
        type: 'line',
        data: [[5, 1.8195], [5, 1.8195], [6, 1.7690], [6, 1.708]],
        lineStyle: { width: 0 },
        areaStyle: { color: accent2 + '20' },
        stack: 'discount',
        symbol: 'none'
      }
    ]
  });
  window.addEventListener('resize', function() { chart1.resize(); });

  // Chart 2: Premium/Discount Comparison
  var chart2 = echarts.init(document.getElementById('chart-premium'), null, { renderer: 'svg' });
  chart2.setOption({
    animation: false,
    tooltip: { appendToBody: true, trigger: 'axis', formatter: function(params) {
      var p = params[0];
      var val = p.value;
      var type = val < 0 ? '折价' : (val > 0 ? '溢价' : '平价');
      return p.name + '<br/>' + type + '率: ' + val.toFixed(2) + '%';
    }},
    grid: { left: 120, right: 40, top: 30, bottom: 30 },
    xAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: rule } },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } },
      axisLabel: { color: muted, formatter: '{value}%' }
    },
    yAxis: {
      type: 'category',
      data: ['南方中证500ETF联接A', '建信优享科技创新'],
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: ink, fontSize: 12 }
    },
    series: [{
      type: 'bar',
      data: [
        { value: -0.04, itemStyle: { color: accent2 } },
        { value: -0.55, itemStyle: { color: accent2 } }
      ],
      barWidth: 24,
      label: {
        show: true, position: 'left',
        formatter: function(p) { return p.value.toFixed(2) + '%'; },
        color: ink, fontSize: 12, fontWeight: 'bold'
      },
      markLine: {
        silent: true,
        data: [{ xAxis: 0, lineStyle: { color: muted, type: 'solid', width: 2 } }],
        label: { show: false }
      }
    }]
  });
  window.addEventListener('resize', function() { chart2.resize(); });

  // Chart 3: Cost vs Premium
  var chart3 = echarts.init(document.getElementById('chart-cost'), null, { renderer: 'svg' });
  chart3.setOption({
    animation: false,
    tooltip: { appendToBody: true, trigger: 'axis' },
    legend: { top: 0, textStyle: { color: muted, fontSize: 12 } },
    grid: { left: 100, right: 40, top: 40, bottom: 30 },
    xAxis: {
      type: 'value',
      name: '%',
      nameTextStyle: { color: muted },
      axisLine: { lineStyle: { color: rule } },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } },
      axisLabel: { color: muted, formatter: '{value}%' }
    },
    yAxis: {
      type: 'category',
      data: ['160119 (指数联接)', '501098 (主动混合)'],
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: ink, fontSize: 12 }
    },
    series: [
      {
        name: '套利总成本',
        type: 'bar',
        data: [
          { value: -0.45, itemStyle: { color: muted + '80' } },
          { value: -0.83, itemStyle: { color: muted + '80' } }
        ],
        barWidth: 16,
        label: {
          show: true, position: 'inside',
          formatter: function(p) { return Math.abs(p.value).toFixed(2) + '%'; },
          color: '#fff', fontSize: 11
        },
        z: 2
      },
      {
        name: '当前折价幅度',
        type: 'bar',
        data: [
          { value: -0.04, itemStyle: { color: accent2 + '60' } },
          { value: -0.55, itemStyle: { color: accent2 + '60' } }
        ],
        barWidth: 16,
        label: {
          show: true, position: 'left',
          formatter: function(p) { return p.value.toFixed(2) + '%'; },
          color: ink, fontSize: 11, fontWeight: 'bold'
        },
        z: 1
      },
      {
        name: '盈亏平衡线',
        type: 'bar',
        data: [
          { value: -0.45, itemStyle: { color: 'transparent', borderWidth: 2, borderColor: accent } },
          { value: -0.83, itemStyle: { color: 'transparent', borderWidth: 2, borderColor: accent } }
        ],
        barWidth: 16,
        z: 3
      }
    ]
  });
  window.addEventListener('resize', function() { chart3.resize(); });

  // Mermaid init
  if (typeof mermaid !== 'undefined') {
    mermaid.initialize({ startOnLoad: true, theme: 'neutral', securityLevel: 'loose' });
  }
})();
